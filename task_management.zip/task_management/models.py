from django.db import models
from django.contrib.auth.hashers import make_password,check_password

class CustomUser(models.Model):
    ROLE=[("admin","Admin"),("client","Client"),]
    username=models.CharField(max_length=100,unique=True)
    email=models.EmailField(unique=True)
    password=models.CharField(max_length=150)
    role=models.CharField(max_length=50,choices=ROLE)
    is_active=models.BooleanField(default=True)

    def set_password(self,raw_password):
        self.password=make_password(raw_password)

    def check_password(self,raw_password):
        return check_password(raw_password,self.password)

    def __str__(self):
        return self.password