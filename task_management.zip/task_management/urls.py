from django.urls import path
from .views import register_user,login_user,protected_api

urlpatterns=[
    path('register/',register_user,name="register_user"),
    path('login/',login_user,name="login_user"),
    path('protected/',protected_api,name="protected_api"),
]