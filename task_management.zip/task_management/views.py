from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import CustomUser
from .utils import generate_token,verify_token
from drf_spectacular.utils import extend_schema, OpenApiParameter
from drf_spectacular.types import OpenApiTypes
@api_view(["POST"])
def register_user(request):
    username=request.data.get("username")
    email=request.data.get("email")
    password=request.data.get("password")
    role=request.data.get("role")

    if not username or not email or not password or not role:
        return Response({
            "error":"all fields are required"
        },status=400)
    if role not in ["admin","client"]:
        return Response({
            "error":"Invalid role"
        },status=400)
    if CustomUser.objects.filter(username=username).exists():
        return Response({
            "error":"username already exists"
        },status=400)
    if CustomUser.objects.filter(email=email).exists():
        return Response({
            "error":"email already exists"
        },status=400)

    user=CustomUser(
        username=username,
        email=email,
        role=role
    )
    user.set_password(password)
    user.save()

    return Response({
        "message":"user register successfully",
        "username":user.username,
        "role":user.role,
    },status=201)

@api_view(["POST"])
def login_user(request):
    username=request.data.get("username")
    password=request.data.get("password")

    if not username or not password:
        return Response({
            "error":"username and password are required"
        },status=400)

    try:
        user=CustomUser.objects.get(username=username)
    except CustomUser.DoesNotExist:
        return Response({
            "error":"invalid username or password"
        },status=401)

    if not user.is_active:
        return Response({
            "error":"account id invalid"
        },status=403)
    if not user.check_password(password):
        return Response({
            "error":"invalid username or password"
        },status=401)
    
    token=generate_token(user)

    return Response({
        "message":"login successful",
        "token":token,
        "user_id":user.id,
        "username":user.username
    },status=200)

@api_view(["GET"])
def protected_api(request):
    token=request.headers.get("Authorization")

    if not token:
        return Response({
            "error":"token required"
        },status=401)
    
    token=token.replace("Bearer ", "")

    data=verify_token(token)

    if not data:
        return Response({
            "error":"invalid token"
        },status=401)
    
    return Response({
        "message":"login verified",
        "user_id":data["user_id"]
    })
